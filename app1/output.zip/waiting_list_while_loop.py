
waiting_lists = ['Andrew','Weverson', 'Luana', 'Manuela', 'Liz']
# waiting_lists.sort()

for index, item in enumerate(waiting_lists):
    row = f'{index + 1}.{item.capitalize()}'
    print(row)




