'''
glob allows you to filter. The example below filters all files with extention .txt
import glob
myfiles = glob.glob("files/*txt")
print(myfiles)
'''

import shutil
shutil.make_archive("output", "zip")



